#!/bin/bash
find . -iname '*.py' 1> py_scripts 2> py_errors

